import re
from halogenase_miner.categorization.signature_search import (
    get_catalytic_residues,
    search_motif,
    compare_to_enzyme,
    get_family_specifics
)
from halogenase_miner.categorization.family_categorization import (
    EnzymeFamily,
    FDHs,
    NONHEME_IRON)
from halogenase_miner.motif_db.motifs import VBPO

dimetal = EnzymeFamily("test/ssn/dimetal_carboxylate.fasta")
dimetal.dimetal_carboxylate.dimetal_first_motif_matches
dimetal.dimetal_carboxylate.dimetal_second_motif_matches
matches = get_catalytic_residues(dimetal.dimetal_carboxylate.dimetal_hits, list(range(130, 150)))
matches.keys()

res = EnzymeFamily("test/fdh_conventional.fasta")
motif_matches = res.flavin_dependent.fdh_motif_based_categorization()
res.flavin_dependent

vhpo = EnzymeFamily("test/VHPO_ssn.fasta")
vhpo.vanadium_dependent.vhpo_categorize_selective_chlorinases()
vhpo.vanadium_dependent.vhpo_categorize_iodinases()
vhpo.vanadium_dependent.vhpo_categorize_brominases()
vhpo.vanadium_dependent.vhpo_intermol_categorize_brominases()

sams = EnzymeFamily("test/sam_ssn.fasta")

nhfehals = EnzymeFamily("test/nhfe_ssn.fasta")
varaint_b = nhfehals.non_hemes.variant_b_hits
nucleotide = nhfehals.non_hemes.nucleotide_hits
indole_alkaloid = nhfehals.non_hemes.indole_alkaloid_hits
small_amino_acids = nhfehals.non_hemes.amino_acid_hits

variant_b_triad = nhfehals.non_hemes.nonheme_halogenase_catalytic_triad(varaint_b)
unique_variant_b = nhfehals.non_hemes.unique_variant_b_motif(varaint_b)
nucleotide_triad = nhfehals.non_hemes.nucleotide_catalytic_triad(nucleotide)
indole_alkaloid_triad = nhfehals.non_hemes.nonheme_halogenase_catalytic_triad(indole_alkaloid)
small_amino_acids_triad = nhfehals.non_hemes.nonheme_halogenase_catalytic_triad(small_amino_acids)

len(variant_b_triad)
len(unique_variant_b)
len(nucleotide_triad)
len(indole_alkaloid_triad)
len(small_amino_acids_triad)

all_enzymes = list(set(variant_b_triad+nucleotide_triad+indole_alkaloid_triad+small_amino_acids_triad+unique_variant_b))
len(all_enzymes)

with open('nhfe_hal_ssn.txt', 'w') as f:
    for line in all_enzymes:
        f.write(f"{line}\n")

aetf = EnzymeFamily("/home/szenei/hal_miner/test/specific_enzymes/aetf.fasta")
aetf_residues = get_catalytic_residues(aetf.flavin_dependent.unconventional_hits, list((range(10, 20))))
aetf_residues