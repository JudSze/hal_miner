import re
from halogenase_miner.categorization.signature_search import (
    get_catalytic_residues,
    search_motif,
    compare_to_enzyme,
    get_family_specifics
)
from halogenase_miner.categorization.family_categorization import (
    EnzymeFamily,
    FDHs)
from halogenase_miner.motif_db.motifs import VBPO

res = EnzymeFamily("test/fdh_conventional.fasta")
motif_matches = res.flavin_dependent.fdh_motif_based_categorization()
res.flavin_dependent

with open('fdh_conventional_both_motifs.txt', 'w') as f:
    for line in motif_matches["both_motifs"]:
        f.write(f"{line}\n")

vhpo = EnzymeFamily("test/VHPO_ssn.fasta")
vhpo.vanadium_dependent.vhpo_categorize_selective_chlorinases()
vhpo.vanadium_dependent.vhpo_categorize_iodinases()
vhpo.vanadium_dependent.vhpo_categorize_brominases()
vhpo.vanadium_dependent.vhpo_intermol_categorize_brominases()

sams = EnzymeFamily("test/sam_ssn.fasta")
fluorinases = sams.sam_dependent.

len(sams.sam_dependent.fluorinase_hits)
sams.sam_dependent.fluorinase_hits
chlorinases = compare_to_enzyme(fluorinases, "sam-dependent","flA4")
compare_to_enzyme(sams.sam_dependent.fluorinase_hits, "sam-dependent","flA4")

